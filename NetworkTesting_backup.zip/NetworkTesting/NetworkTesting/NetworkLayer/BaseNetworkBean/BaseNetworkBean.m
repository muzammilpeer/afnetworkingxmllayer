//
//  BaseNetworkBean.m
//  Communique
//
//  Created by Hussain Mansoor on 8/1/14.
//  Copyright (c) 2014 Foomo. All rights reserved.
//

#import "BaseNetworkBean.h"

@implementation BaseNetworkBean

@end
