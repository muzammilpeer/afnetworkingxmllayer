//
//  collectionViewBaseCellCollectionViewCell.h
//  collectionViewTest
//
//  Created by Faran Rasheed on 27/11/2014.
//  Copyright (c) 2014 Faran Rasheed. All rights reserved.
//

@interface BaseCollectionViewCell : UICollectionViewCell

-(void)updateCell:(id)model;
@end
