//
//  BaseTableViewCell.h
//  sharqa
//
//  Created by Muzammil Peer on 11/12/14.
//  Copyright (c) 2014 Sytems Ltd. All rights reserved.
//


@interface BaseTableViewCell : UITableViewCell

-(void)updateCell:(id)model;

@end
